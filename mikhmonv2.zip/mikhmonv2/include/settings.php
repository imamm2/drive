<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// hide all error
//error_reporting(0);

include_once('./config.php');
include_once('../lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');
$API = new RouterosAPI();
$API->debug = false;


if(!isset($_SESSION["$userhost"])){
	header("Location:./");
}

if(substr(formatBytes2($maxtx,2),-2) == "MB" || substr(formatBytes2($maxrx,2),-2) == "MB"){
    $vmaxtx = $maxtx/1000000;
    $vmaxrx = $maxrx/1000000;
  }elseif(substr(formatBytes2($maxtx,2),-2) == "GB" || substr(formatBytes2($maxrx,2),-2) == "GB"){
   $vmaxtx = $maxtx/1000000000;
   $vmaxrx = $maxrx/1000000000;
  }elseif($maxtx == "" || $maxrx== ""){
    $vmaxtx = "";
    $vmaxrx = "";
  }

$url = $_SERVER['REQUEST_URI'];
if(isset($_POST['save'])){
	$setupdata = ($_POST['setupdata']);
	$siphost = ($_POST['ipmik']);
	$suserhost = ($_POST['usermik']);
	$spasswdhost = encrypt($_POST['passmik']);
	$suseradm = ($_POST['useradm']);
	$spassadm = encrypt($_POST['passadm']);
    $shotspotname = ($_POST['hotspotname']);
    $sdnsname = ($_POST['dnsname']);
    $scurency = ($_POST['curency']);
    $reload = ($_POST['areload']);
    $iface = ($_POST['iface']);
    $maxtx = ($_POST['maxtx']);
    $maxrx = ($_POST['maxrx']);
    $mbgbtx = ($_POST['mbgbtx']);
    $mbgbrx = ($_POST['mbgbrx']);
    if($maxtx == ""){$maxtx = "0";}else{$maxtx = $maxtx*$mbgbtx;}
    if($maxrx == ""){$maxrx = "0";}else{$maxrx = $maxrx*$mbgbrx;}
    if($reload < 5 ){$sareload = 5;}elseif($reload >= 5){$sareload = $reload;}
 
		// Save Local
		if($setupdata == "local"){
		$mconfig = './include/config.php';
		$handleconfig = fopen($mconfig, 'w') or die('Cannot open file:  '.$mconfig);
		
		$dataconfig = '<?php $iphost="'.$siphost.'"; $userhost="'.$suserhost.'"; $passwdhost="'.$spasswdhost.'"; $useradm="'.$suseradm.'"; $passadm="'.$spassadm.'"; $hotspotname="'.$shotspotname.'"; $dnsname="'.$sdnsname.'"; $curency="'.$scurency.'";  $areload="'.$sareload.'";  $iface="'.$iface.'";  $maxtx="'.$maxtx.'"; $maxrx="'.$maxrx.'"; if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");};?>';
    
		fwrite($handleconfig, $dataconfig);
		
		$mareload = './js/autoreload.js';
		$handleareload = fopen($mareload, 'w') or die('Cannot open file:  '.$mareload);
		
		$dataareload = ' $(document).ready(function(){ var interval = "'.$sareload.'000"; setInterval(function() { $("#reloadHome").load("./include/home.php"); }, interval); setInterval(function() { $("#reloadHotspotActive").load("./include/hotspotactive.php"); }, interval);});';
    
		fwrite($handleareload, $dataareload);
		
		
	// Export to MikroTik
	}elseif($setupdata == "export"){
	  $API->connect( $iphost, $userhost, decrypt($passwdhost));
	   $arrID=$API->comm("/system/script/getall",
						  array(
				  ".proplist"=> ".id",
				  "?name" => "mikhmonv2",
				  ));
	    $API->comm("/system/script/remove", array(
	    ".id" => $arrID[0][".id"],
	    ));
	  
      $export = "$shotspotname-|-$sdnsname-|-$scurency-|-$sareload-|-$iface-|-$maxtx-|-$maxrx";
  
    $API->comm("/system/script/add", array(
					  "name" => "mikhmonv2",
					  "source" => "$export",
			));
  
  
//Import from MikroTik
	}elseif($setupdata == "import"){
	 $API->connect( $iphost, $userhost, decrypt($passwdhost));
	 $getmikhmondata = $API->comm("/system/script/print", array(
	    "?name" => "mikhmonv2"));
    $import = $getmikhmondata[0]['source'];
    if($import == ""){}else{
    $importv = explode("-|-",$import);
   $shotspotname = $importv[0];
   $sdnsname = $importv[1];
   $scurency = $importv[2];
   $sareload = $importv[3];
   $iface = $importv[4];
   $maxtx = $importv[5];
   $maxrx = $importv[6];

	  $mconfig = './include/config.php';
		$handleconfig = fopen($mconfig, 'w') or die('Cannot open file:  '.$mconfig);
		
		$dataconfig = '<?php $iphost="'.$siphost.'"; $userhost="'.$suserhost.'"; $passwdhost="'.$spasswdhost.'"; $useradm="'.$suseradm.'"; $passadm="'.$spassadm.'"; $hotspotname="'.$shotspotname.'"; $dnsname="'.$sdnsname.'"; $curency="'.$scurency.'"; $areload="'.$sareload.'"; $iface="'.$iface.'"; $maxtx="'.$maxtx.'"; $maxrx="'.$maxrx.'"; if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");};?>';
    
		fwrite($handleconfig, $dataconfig);
		
		$mareload = './js/autoreload.js';
		$handleareload = fopen($mareload, 'w') or die('Cannot open file:  '.$mareload);
		
		$dataareload = ' $(document).ready(function(){ var interval = "'.$sareload.'000"; setInterval(function() { $("#reloadHome").load("./include/home.php"); }, interval); setInterval(function() { $("#reloadHotspotActive").load("./include/hotspotactive.php"); }, interval);});';
    
		fwrite($handleareload, $dataareload);
	}
	}
	$_SESSION["connect"] = "";
	include_once('./include/config.php');
	$_SESSION["$userhost"]=$userhost;
	echo "<script>window.location='./admin.php?id=settings'</script>";
	}
?>
<script>
  function PassMk(){
    var x = document.getElementById('passmk');
    if (x.type === 'password') {
    x.type = 'text';
    } else {
    x.type = 'password';
    }}
    function PassAdm(){
    var x = document.getElementById('passadm');
    if (x.type === 'password') {
    x.type = 'text';
    } else {
    x.type = 'password';
  }}
</script>
<div class="settings">
<div class="row">
	<div class="col-12">
  				<div class="card" >
  					<div class="card-header">
       					<h3 class="card-title"><i class="fa fa-gear"></i> Mikhmon Settings</h3>
    				</div>
    <div class="card-body">
    	<div class="row">
			<div class="col-6">
				<div class="card">
        	<div class="card-header">
            	<h3 class="card-title">MikroTik<?php echo " <b>". $_SESSION["connect"]."</b>";?></h3>
        	</div>
        	<div class="card-body">
    	<form autocomplete="off" method="post" action="">
		
				<table class="table table-sm">
					<tr>
	  					<td class="align-middle">IP MikroTik  </td><td><input class="form-control" type="text" size="15" name="ipmik" title="IP MikroTik / IP Cloud MikroTik" value="<?php echo $iphost; ?>" required="1"/></td>
					</tr>
					<tr>
						<td class="align-middle">Username  </td><td><input class="form-control" id="usermk" type="text" size="10" name="usermik" title="User MikroTik" value="<?php echo $userhost; ?>" required="1"/></td>
					</tr>
					<tr>
						<td class="align-middle">Password  </td><td>
							<div class="input-group">
								<div class="input-group-11 col-box-10">
        						<input class="group-item group-item-l" id="passmk" type="password" size="10" name="passmik" title="Password MikroTik" value="<?php echo decrypt($passwdhost) ;?>" required="1"/>
        						</div>
            					<div class="input-group-1 col-box-2">
            						<div class="group-item group-item-r pd-2p5 text-center align-middle">
                						<input title="Show/Hide Password" type="checkbox" onclick="PassMk()">
            						</div>
            					</div>
    						</div>
						</td>
					</tr>
					<tr>
						<td colspan="2">
        					<div class="input-group">
            					<div class="input-group-3">
              						<select style="padding:4.2px;" class="group-item group-item-l" name="setupdata" required="1"> 
										<option value="local" title="Save local Mikhmon">Save Local</option>
										<option value="export" title="Export to MikroTik">Export Mikhmon data to MikroTik</option>
										<option value="import" title="Import from MikroTik">Import Mikhmon data  from MikroTik</option>
									</select>
								</div>
								<div class="input-group-2">
									<input class="group-item group-item-md" type="submit" style="cursor: pointer;" name="save" value="Save"/>
								</div>
								<div class="input-group-3">	
									<a class="group-item group-item-md pd-2p5 text-center align-middle" href="./admin.php?id=connect" title="Test connection to MikroTik ">Connect</a>
								</div>
								<div class="input-group-3">	
        								<?php if($_SESSION["$userhost"] != "$userhost"){ echo '<a class="group-item group-item-md pd-2p5 text-center" href="./admin.php?id=login" title="Login">Login</a>';
										}else{echo '<a class="group-item group-item-md pd-2p5 text-center"  href="./" title="Dashboard">Dashboard</a>';}?> 

              					</div>
              					<div class="input-group-1">	
									<div style="cursor: pointer;" class="group-item group-item-r pd-2p5 text-center" onclick="location.reload();" title="Reload Data"><i class="fa fa-refresh"></i></div>
								</div>
            					</div>
          		
    					</td>
    				</tr>
				</table>
			</div>
         		
    	</div>
	<div class="card">
       	<div class="card-header">
           <h3 class="card-title">Admin</h3>
        </div>
			<table class="table table-sm">
				<tr>
					<td class="align-middle">Username  </td><td><input class="form-control" id="useradm" type="text" size="10" name="useradm" title="User Admin" value="<?php echo $useradm; ?>" required="1"/></td>
				</tr>
				<tr>
					<td class="align-middle">Password  </td>
				<td>
					<div class="input-group">
					<div class="input-group-11 col-box-10">	
        				<input class="group-item group-item-l" id="passadm" type="password" size="10" name="passadm" title="Password Admin" value="<?php echo decrypt($passadm); ?>" required="1"/>
        			</div>
             		<div class="input-group-1 col-box-2">
            			<div class="group-item group-item-r pd-2p5 text-center align-middle">
                			<input title="Show/Hide Password" type="checkbox" onclick="PassAdm()">
             			</div>
             		</div>
    				</div>
				</td>
			</tr>
			<tr>
				<td class="align-middle" colspan=2>
					<strong>Please change username and password Admin.</strong>
				</td>
			</tr>
			</table>
    	</div>
    </div>
<div class="col-6">
	<div class="card">
        <div class="card-header">
            <h3 class="card-title">Mikhmon Data</h3>
        </div>
	<table class="table table-sm">
	<tr>
	<td class="align-middle">Hotspot Name  </td><td><input class="form-control" type="text" size="15" maxlength="50" name="hotspotname" title="Hotspot Name" value="<?php echo $hotspotname; ?>" required="1"/></td>
	</tr>
	<tr>
	<td class="align-middle">DNS Name  </td><td><input class="form-control" type="text" size="15" maxlength="500" name="dnsname" title="DNS Name [IP->Hotspot->Server Profiles->DNS Name]" value="<?php echo $dnsname; ?>" required="1"/></td>
	</tr>
	<tr>
	<td class="align-middle">Curency  </td><td><input class="form-control" type="text" size="3" maxlength="4" name="curency" title="Curency" value="<?php echo $curency; ?>" required="1"/></td>
	</tr>
	<tr>
	<td class="align-middle">Auto Reload</td><td>
	<div class="input-group">
		<div class="input-group-10">
        	<input class="group-item group-item-l" type="number" min="10" max="3600" name="areload" title="Auto Reload in sec [min 10s]" value="<?php echo $areload; ?>" required="1"/>
    	</div>
            <div class="input-group-2">
                <span class="group-item group-item-r pd-2p5 text-center align-middle">sec</span>
            </div>
        </div>
	</td>
	</tr>
	<tr>
	<td class="align-middle">Traffic Ether  </td><td><input class="form-control" type="number" min="1" max="99" name="iface" title="Traffic Interface" value="<?php echo $iface; ?>" required="1"/></td>
	</tr>
	<tr>
    <td class="align-middle">Max Tx</td><td>
      <div class="input-group">
      	<div class="input-group-9 col-box-8">
        	<input class="group-item group-item-l" type="number" min="0" max="9999" name="maxtx" value="<?php echo $vmaxtx;?>">
        </div>
          <div class="input-group-3 col-box-4">
              <select style="padding: 4.2px;" class="group-item group-item-r" name="mbgbtx" required="1">
				        <option value=1000000>MB</option>
				        <option value=1000000000>GB</option>
			        </select>
          </div>
      </div>
    </td>
  </tr>
  <tr>
    <td class="align-middle">Max Rx</td><td>
      <div class="input-group">
      	<div class="input-group-9 col-box-8">
        	<input class="group-item group-item-l" type="number" min="0" max="9999" name="maxrx" value="<?php echo $vmaxrx;?>">
        </div>
          <div class="input-group-3 col-box-4">
              <select style="padding: 4.2px;" class="group-item group-item-r" name="mbgbrx" required="1">
				        <option value=1000000>MB</option>
				        <option value=1000000000>GB</option>
			        </select>
          </div>
      </div>
    </td>
  </tr>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</form>
</div>

<!-- /.login-box -->
<script type="text/javascript">
	var mk = document.getElementById('usermk');
  	var adm = document.getElementById('useradm');
	useradm.addEventListener("input", function (e) {
  	if (mk.value === adm.value){
  		alert('Username MikroTik should not be the same with username Admin');
  		adm.value = '';
  	}});
</script>





