<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
session_start();
?>
<?php
error_reporting(0);

include('../include/config.php');
include('../lib/formatbytesbites.php');

if(!isset($_SESSION["$userhost"])){
	header("Location:../admin.php?id=login");
}
$url = $_SERVER['REQUEST_URI'];
$id = $_GET['id'];
if($id == "default" || $id == "rdefault"){
  $idt = "template";
}elseif($id == "thermal" || $id == "rthermal"){
  $idt = "template-thermal";
}elseif($id == "small" || $id == "rsmall"){
  $idt = "template-small";
}
  if(isset($_POST['save'])){
    $template = './'.$idt.'.php';
		$handle = fopen($template, 'w') or die('Cannot open file:  '.$template);
		
		$data = ($_POST['editor']);
    
		fwrite($handle, $data);
		
		//header("Location:$url");
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>.:: MIKHMON Template Editor::.</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="pragma" content="no-cache" />
		<link rel="icon" href="../img/favicon.png" />
		<link rel="stylesheet" href="../css/mikhmon-ui.css">
		<link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.min.css" />
		<style>
textarea{
  font-size:12px;
  border: 1px solid #2f353a;
}

	</style>
	</head>
	<body>
		<div class="wrapper" >
			<div class="row">
	      	<div class="col-10">
	      		<div class="card">
					<div class="card-header">
						<h3><i class="fa fa-edit"></i> Template Editor</h3>
					</div>
				<div class="card-body">
	  				<form autocomplete="off" method="post" action="">
	  		<table class="table">
	  			<tr>
	  				<td>
	  					<a class="btn bg-warning text-dark" href="../" title="Close"><i class="fa fa-close"></i> Close</a>
	          			<button type="submit" title="Save template" class="btn bg-primary" name="save"><i class="fa fa-save"></i> Save</button>
	      			</td>
	      	<td>
	      	<div class="input-group">
            	<div class="input-group-6">
            		<div class="group-item group-item-l pd-2p5 text-center">Template</div>
            	</div>
	      		<div class="input-group-6">
	          		<select style="padding:4.2px;"  class="group-item group-item-r" onchange="window.location.href=this.value;">
	          			<option><?php echo $id;?></option>
	          			<option value="./editor.php?id=default">Default</option>
	          			<option value="./editor.php?id=thermal">Thermal</option>
	          			<option value="./editor.php?id=small">Small</option>
	          		</select>
	      		</div>
	  		</div>
	    </td>
	    <td>
	      	<div class="input-group">
            	<div class="input-group-6">
            		<div class="group-item group-item-l pd-2p5 text-center">Reset</div>
            	</div>
	      		<div class="input-group-6">
	          		<select style="padding:4.2px;"  class="group-item group-item-r" onchange="window.location.href=this.value;">
	          			<option><?php echo $id;?></option>
	          			<option value="./editor.php?id=rdefault">Default</option>
	          			<option value="./editor.php?id=rthermal">Thermal</option>
	          			<option value="./editor.php?id=rsmall">Small</option>
	          		</select>
	          	</div>
	          </div>
	      </td>
	      </tr>
	  </table>
	          <textarea id="editor" class="bg-dark" name="editor" style="width:100%" rows=40>
	            <?php if($id == "default"){?>
	            <?=file_get_contents ('./template.php');?>
	            <?php }elseif($id == "thermal"){?>
	              <?=file_get_contents ('./template-thermal.php');?>
	            <?php }elseif($id == "small"){?>
	              <?=file_get_contents ('./template-small.php');?>
	           <?php }elseif($id == "rdefault"){?>
	            <?=file_get_contents ('./default.php');?>
	            <?php }elseif($id == "rthermal"){?>
	              <?=file_get_contents ('./default-thermal.php');?>
	            <?php }elseif($id == "rsmall"){?>
	              <?=file_get_contents ('./default-small.php');?>
	            <?php }?>
	          </textarea>
	  </form>
	</div>
</div>
</div>
<div class="col-2">
	<div class="card">
		<div class="card-header">
			<h3>Variable</h3>
		</div>
	<div class="card-body">
		<textarea class="bg-dark" readonly rows=43 style="width:100%" >
	        <?=file_get_contents ('./variable.php');?>
	    </textarea>
	</div>
	</div>
</div>
</div>
</div>
</body>
</html>
